﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPTsGrille
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radGrilledCheese = New System.Windows.Forms.RadioButton()
        Me.radBltSandwich = New System.Windows.Forms.RadioButton()
        Me.radTurkeySandwich = New System.Windows.Forms.RadioButton()
        Me.radPtDog = New System.Windows.Forms.RadioButton()
        Me.radBlackBean = New System.Windows.Forms.RadioButton()
        Me.radGardenBurger = New System.Windows.Forms.RadioButton()
        Me.radRoastBeef = New System.Windows.Forms.RadioButton()
        Me.radGrilledChicken = New System.Windows.Forms.RadioButton()
        Me.radPtBurger = New System.Windows.Forms.RadioButton()
        Me.radOldFashionedBurger = New System.Windows.Forms.RadioButton()
        Me.grpBottleToppings = New System.Windows.Forms.GroupBox()
        Me.chkMustard = New System.Windows.Forms.CheckBox()
        Me.chkKetchup = New System.Windows.Forms.CheckBox()
        Me.chkMayo = New System.Windows.Forms.CheckBox()
        Me.grpVeggieToppings = New System.Windows.Forms.GroupBox()
        Me.chkPickels = New System.Windows.Forms.CheckBox()
        Me.chkOnion = New System.Windows.Forms.CheckBox()
        Me.chkTomato = New System.Windows.Forms.CheckBox()
        Me.chkLettuce = New System.Windows.Forms.CheckBox()
        Me.grpCheese = New System.Windows.Forms.GroupBox()
        Me.radJack = New System.Windows.Forms.RadioButton()
        Me.radAmerican = New System.Windows.Forms.RadioButton()
        Me.grpMeat = New System.Windows.Forms.GroupBox()
        Me.chkChili = New System.Windows.Forms.CheckBox()
        Me.chkBacon = New System.Windows.Forms.CheckBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblDrinks = New System.Windows.Forms.Label()
        Me.cmbDrink = New System.Windows.Forms.ComboBox()
        Me.grpDestination = New System.Windows.Forms.GroupBox()
        Me.radPickUp = New System.Windows.Forms.RadioButton()
        Me.radTakeOut = New System.Windows.Forms.RadioButton()
        Me.radInside = New System.Windows.Forms.RadioButton()
        Me.btnSubmitOrder = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.grpBottleToppings.SuspendLayout()
        Me.grpVeggieToppings.SuspendLayout()
        Me.grpCheese.SuspendLayout()
        Me.grpMeat.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpDestination.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radGrilledCheese)
        Me.GroupBox1.Controls.Add(Me.radBltSandwich)
        Me.GroupBox1.Controls.Add(Me.radTurkeySandwich)
        Me.GroupBox1.Controls.Add(Me.radPtDog)
        Me.GroupBox1.Controls.Add(Me.radBlackBean)
        Me.GroupBox1.Controls.Add(Me.radGardenBurger)
        Me.GroupBox1.Controls.Add(Me.radRoastBeef)
        Me.GroupBox1.Controls.Add(Me.radGrilledChicken)
        Me.GroupBox1.Controls.Add(Me.radPtBurger)
        Me.GroupBox1.Controls.Add(Me.radOldFashionedBurger)
        Me.GroupBox1.Font = New System.Drawing.Font("Comic Sans MS", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(2, 87)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(199, 317)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Sandwich"
        '
        'radGrilledCheese
        '
        Me.radGrilledCheese.AutoSize = True
        Me.radGrilledCheese.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radGrilledCheese.Location = New System.Drawing.Point(5, 264)
        Me.radGrilledCheese.Name = "radGrilledCheese"
        Me.radGrilledCheese.Size = New System.Drawing.Size(177, 22)
        Me.radGrilledCheese.TabIndex = 9
        Me.radGrilledCheese.TabStop = True
        Me.radGrilledCheese.Text = "Grilled Cheese Sandwich"
        Me.radGrilledCheese.UseVisualStyleBackColor = True
        '
        'radBltSandwich
        '
        Me.radBltSandwich.AutoSize = True
        Me.radBltSandwich.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radBltSandwich.Location = New System.Drawing.Point(6, 236)
        Me.radBltSandwich.Name = "radBltSandwich"
        Me.radBltSandwich.Size = New System.Drawing.Size(122, 22)
        Me.radBltSandwich.TabIndex = 8
        Me.radBltSandwich.TabStop = True
        Me.radBltSandwich.Text = "B.L.T. Sandwich"
        Me.radBltSandwich.UseVisualStyleBackColor = True
        '
        'radTurkeySandwich
        '
        Me.radTurkeySandwich.AutoSize = True
        Me.radTurkeySandwich.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radTurkeySandwich.Location = New System.Drawing.Point(5, 208)
        Me.radTurkeySandwich.Name = "radTurkeySandwich"
        Me.radTurkeySandwich.Size = New System.Drawing.Size(136, 22)
        Me.radTurkeySandwich.TabIndex = 7
        Me.radTurkeySandwich.TabStop = True
        Me.radTurkeySandwich.Text = "Turkey Sandwich "
        Me.radTurkeySandwich.UseVisualStyleBackColor = True
        '
        'radPtDog
        '
        Me.radPtDog.AutoSize = True
        Me.radPtDog.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPtDog.Location = New System.Drawing.Point(6, 185)
        Me.radPtDog.Name = "radPtDog"
        Me.radPtDog.Size = New System.Drawing.Size(75, 22)
        Me.radPtDog.TabIndex = 6
        Me.radPtDog.TabStop = True
        Me.radPtDog.Text = "P.T. Dog"
        Me.radPtDog.UseVisualStyleBackColor = True
        '
        'radBlackBean
        '
        Me.radBlackBean.AutoSize = True
        Me.radBlackBean.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radBlackBean.Location = New System.Drawing.Point(6, 161)
        Me.radBlackBean.Name = "radBlackBean"
        Me.radBlackBean.Size = New System.Drawing.Size(141, 22)
        Me.radBlackBean.TabIndex = 5
        Me.radBlackBean.TabStop = True
        Me.radBlackBean.Text = "Black Bean Burger "
        Me.radBlackBean.UseVisualStyleBackColor = True
        '
        'radGardenBurger
        '
        Me.radGardenBurger.AutoSize = True
        Me.radGardenBurger.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radGardenBurger.Location = New System.Drawing.Point(6, 137)
        Me.radGardenBurger.Name = "radGardenBurger"
        Me.radGardenBurger.Size = New System.Drawing.Size(119, 22)
        Me.radGardenBurger.TabIndex = 4
        Me.radGardenBurger.TabStop = True
        Me.radGardenBurger.Text = "Garden Burger "
        Me.radGardenBurger.UseVisualStyleBackColor = True
        '
        'radRoastBeef
        '
        Me.radRoastBeef.AutoSize = True
        Me.radRoastBeef.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radRoastBeef.Location = New System.Drawing.Point(6, 113)
        Me.radRoastBeef.Name = "radRoastBeef"
        Me.radRoastBeef.Size = New System.Drawing.Size(159, 22)
        Me.radRoastBeef.TabIndex = 3
        Me.radRoastBeef.TabStop = True
        Me.radRoastBeef.Text = "Roast Beef Sandwich "
        Me.radRoastBeef.UseVisualStyleBackColor = True
        '
        'radGrilledChicken
        '
        Me.radGrilledChicken.AutoSize = True
        Me.radGrilledChicken.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radGrilledChicken.Location = New System.Drawing.Point(6, 90)
        Me.radGrilledChicken.Name = "radGrilledChicken"
        Me.radGrilledChicken.Size = New System.Drawing.Size(186, 22)
        Me.radGrilledChicken.TabIndex = 2
        Me.radGrilledChicken.TabStop = True
        Me.radGrilledChicken.Text = "Grilled Chicken Sandwich "
        Me.radGrilledChicken.UseVisualStyleBackColor = True
        '
        'radPtBurger
        '
        Me.radPtBurger.AutoSize = True
        Me.radPtBurger.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPtBurger.Location = New System.Drawing.Point(6, 65)
        Me.radPtBurger.Name = "radPtBurger"
        Me.radPtBurger.Size = New System.Drawing.Size(93, 22)
        Me.radPtBurger.TabIndex = 1
        Me.radPtBurger.TabStop = True
        Me.radPtBurger.Text = "P.T. Burger"
        Me.radPtBurger.UseVisualStyleBackColor = True
        '
        'radOldFashionedBurger
        '
        Me.radOldFashionedBurger.AutoSize = True
        Me.radOldFashionedBurger.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radOldFashionedBurger.Location = New System.Drawing.Point(6, 37)
        Me.radOldFashionedBurger.Name = "radOldFashionedBurger"
        Me.radOldFashionedBurger.Size = New System.Drawing.Size(162, 22)
        Me.radOldFashionedBurger.TabIndex = 0
        Me.radOldFashionedBurger.TabStop = True
        Me.radOldFashionedBurger.Text = "Old Fashioned Burger "
        Me.radOldFashionedBurger.UseVisualStyleBackColor = True
        '
        'grpBottleToppings
        '
        Me.grpBottleToppings.Controls.Add(Me.chkMustard)
        Me.grpBottleToppings.Controls.Add(Me.chkKetchup)
        Me.grpBottleToppings.Controls.Add(Me.chkMayo)
        Me.grpBottleToppings.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpBottleToppings.Location = New System.Drawing.Point(211, 87)
        Me.grpBottleToppings.Name = "grpBottleToppings"
        Me.grpBottleToppings.Size = New System.Drawing.Size(105, 88)
        Me.grpBottleToppings.TabIndex = 7
        Me.grpBottleToppings.TabStop = False
        Me.grpBottleToppings.Text = "Bottle Toppings"
        '
        'chkMustard
        '
        Me.chkMustard.AutoSize = True
        Me.chkMustard.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkMustard.ForeColor = System.Drawing.Color.Yellow
        Me.chkMustard.Location = New System.Drawing.Point(16, 65)
        Me.chkMustard.Name = "chkMustard"
        Me.chkMustard.Size = New System.Drawing.Size(68, 19)
        Me.chkMustard.TabIndex = 2
        Me.chkMustard.Text = "Mustard"
        Me.chkMustard.UseVisualStyleBackColor = True
        '
        'chkKetchup
        '
        Me.chkKetchup.AutoSize = True
        Me.chkKetchup.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkKetchup.ForeColor = System.Drawing.Color.Red
        Me.chkKetchup.Location = New System.Drawing.Point(16, 42)
        Me.chkKetchup.Name = "chkKetchup"
        Me.chkKetchup.Size = New System.Drawing.Size(67, 19)
        Me.chkKetchup.TabIndex = 1
        Me.chkKetchup.Text = "Ketchup"
        Me.chkKetchup.UseVisualStyleBackColor = True
        '
        'chkMayo
        '
        Me.chkMayo.AutoSize = True
        Me.chkMayo.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkMayo.ForeColor = System.Drawing.Color.PeachPuff
        Me.chkMayo.Location = New System.Drawing.Point(16, 19)
        Me.chkMayo.Name = "chkMayo"
        Me.chkMayo.Size = New System.Drawing.Size(54, 19)
        Me.chkMayo.TabIndex = 0
        Me.chkMayo.Text = "Mayo"
        Me.chkMayo.UseVisualStyleBackColor = True
        '
        'grpVeggieToppings
        '
        Me.grpVeggieToppings.Controls.Add(Me.chkPickels)
        Me.grpVeggieToppings.Controls.Add(Me.chkOnion)
        Me.grpVeggieToppings.Controls.Add(Me.chkTomato)
        Me.grpVeggieToppings.Controls.Add(Me.chkLettuce)
        Me.grpVeggieToppings.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpVeggieToppings.Location = New System.Drawing.Point(211, 181)
        Me.grpVeggieToppings.Name = "grpVeggieToppings"
        Me.grpVeggieToppings.Size = New System.Drawing.Size(105, 115)
        Me.grpVeggieToppings.TabIndex = 8
        Me.grpVeggieToppings.TabStop = False
        Me.grpVeggieToppings.Text = "Veggies"
        '
        'chkPickels
        '
        Me.chkPickels.AutoSize = True
        Me.chkPickels.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPickels.ForeColor = System.Drawing.Color.Lime
        Me.chkPickels.Location = New System.Drawing.Point(16, 91)
        Me.chkPickels.Name = "chkPickels"
        Me.chkPickels.Size = New System.Drawing.Size(62, 19)
        Me.chkPickels.TabIndex = 3
        Me.chkPickels.Text = "Pickels"
        Me.chkPickels.UseVisualStyleBackColor = True
        '
        'chkOnion
        '
        Me.chkOnion.AutoSize = True
        Me.chkOnion.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkOnion.ForeColor = System.Drawing.Color.Purple
        Me.chkOnion.Location = New System.Drawing.Point(16, 67)
        Me.chkOnion.Name = "chkOnion"
        Me.chkOnion.Size = New System.Drawing.Size(57, 19)
        Me.chkOnion.TabIndex = 2
        Me.chkOnion.Text = "Onion"
        Me.chkOnion.UseVisualStyleBackColor = True
        '
        'chkTomato
        '
        Me.chkTomato.AutoSize = True
        Me.chkTomato.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkTomato.ForeColor = System.Drawing.Color.Tomato
        Me.chkTomato.Location = New System.Drawing.Point(16, 43)
        Me.chkTomato.Name = "chkTomato"
        Me.chkTomato.Size = New System.Drawing.Size(63, 19)
        Me.chkTomato.TabIndex = 1
        Me.chkTomato.Text = "Tomato"
        Me.chkTomato.UseVisualStyleBackColor = True
        '
        'chkLettuce
        '
        Me.chkLettuce.AutoSize = True
        Me.chkLettuce.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkLettuce.ForeColor = System.Drawing.Color.LightGreen
        Me.chkLettuce.Location = New System.Drawing.Point(16, 19)
        Me.chkLettuce.Name = "chkLettuce"
        Me.chkLettuce.Size = New System.Drawing.Size(64, 19)
        Me.chkLettuce.TabIndex = 0
        Me.chkLettuce.Text = "Lettuce"
        Me.chkLettuce.UseVisualStyleBackColor = True
        '
        'grpCheese
        '
        Me.grpCheese.Controls.Add(Me.radJack)
        Me.grpCheese.Controls.Add(Me.radAmerican)
        Me.grpCheese.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpCheese.Location = New System.Drawing.Point(211, 302)
        Me.grpCheese.Name = "grpCheese"
        Me.grpCheese.Size = New System.Drawing.Size(105, 66)
        Me.grpCheese.TabIndex = 9
        Me.grpCheese.TabStop = False
        Me.grpCheese.Text = "Cheese"
        '
        'radJack
        '
        Me.radJack.AutoSize = True
        Me.radJack.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radJack.Location = New System.Drawing.Point(16, 44)
        Me.radJack.Name = "radJack"
        Me.radJack.Size = New System.Drawing.Size(50, 19)
        Me.radJack.TabIndex = 1
        Me.radJack.TabStop = True
        Me.radJack.Text = "Jack"
        Me.radJack.UseVisualStyleBackColor = True
        '
        'radAmerican
        '
        Me.radAmerican.AutoSize = True
        Me.radAmerican.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radAmerican.Location = New System.Drawing.Point(16, 20)
        Me.radAmerican.Name = "radAmerican"
        Me.radAmerican.Size = New System.Drawing.Size(74, 19)
        Me.radAmerican.TabIndex = 0
        Me.radAmerican.TabStop = True
        Me.radAmerican.Text = "American"
        Me.radAmerican.UseVisualStyleBackColor = True
        '
        'grpMeat
        '
        Me.grpMeat.Controls.Add(Me.chkChili)
        Me.grpMeat.Controls.Add(Me.chkBacon)
        Me.grpMeat.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpMeat.Location = New System.Drawing.Point(211, 371)
        Me.grpMeat.Name = "grpMeat"
        Me.grpMeat.Size = New System.Drawing.Size(105, 57)
        Me.grpMeat.TabIndex = 10
        Me.grpMeat.TabStop = False
        Me.grpMeat.Text = "Meat Toppings"
        '
        'chkChili
        '
        Me.chkChili.AutoSize = True
        Me.chkChili.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkChili.Location = New System.Drawing.Point(16, 38)
        Me.chkChili.Name = "chkChili"
        Me.chkChili.Size = New System.Drawing.Size(50, 19)
        Me.chkChili.TabIndex = 1
        Me.chkChili.Text = "Chili"
        Me.chkChili.UseVisualStyleBackColor = True
        '
        'chkBacon
        '
        Me.chkBacon.AutoSize = True
        Me.chkBacon.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBacon.Location = New System.Drawing.Point(16, 20)
        Me.chkBacon.Name = "chkBacon"
        Me.chkBacon.Size = New System.Drawing.Size(57, 19)
        Me.chkBacon.TabIndex = 0
        Me.chkBacon.Text = "Bacon"
        Me.chkBacon.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.PTs_Grille.My.Resources.Resources.pts_grille_header
        Me.PictureBox1.Location = New System.Drawing.Point(1, 1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(392, 69)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(105, 410)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 17
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(12, 410)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(50, 19)
        Me.lblName.TabIndex = 18
        Me.lblName.Text = "Name:"
        '
        'lblDrinks
        '
        Me.lblDrinks.AutoSize = True
        Me.lblDrinks.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDrinks.Location = New System.Drawing.Point(12, 445)
        Me.lblDrinks.Name = "lblDrinks"
        Me.lblDrinks.Size = New System.Drawing.Size(95, 19)
        Me.lblDrinks.TabIndex = 19
        Me.lblDrinks.Text = "Drink Choice:"
        '
        'cmbDrink
        '
        Me.cmbDrink.FormattingEnabled = True
        Me.cmbDrink.Items.AddRange(New Object() {"Pepsi", "Sierra Mist", "Diet Pepsi", "Mt. Dew", "Rootbeer", "Dr. Pepper", "Tea(sweet)", "Tea(Unsweet)", "Fresh Lemonade", "Water"})
        Me.cmbDrink.Location = New System.Drawing.Point(105, 442)
        Me.cmbDrink.Name = "cmbDrink"
        Me.cmbDrink.Size = New System.Drawing.Size(121, 21)
        Me.cmbDrink.TabIndex = 20
        '
        'grpDestination
        '
        Me.grpDestination.Controls.Add(Me.radPickUp)
        Me.grpDestination.Controls.Add(Me.radTakeOut)
        Me.grpDestination.Controls.Add(Me.radInside)
        Me.grpDestination.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpDestination.Location = New System.Drawing.Point(8, 469)
        Me.grpDestination.Name = "grpDestination"
        Me.grpDestination.Size = New System.Drawing.Size(301, 45)
        Me.grpDestination.TabIndex = 21
        Me.grpDestination.TabStop = False
        Me.grpDestination.Text = "Destination"
        '
        'radPickUp
        '
        Me.radPickUp.AutoSize = True
        Me.radPickUp.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radPickUp.Location = New System.Drawing.Point(203, 22)
        Me.radPickUp.Name = "radPickUp"
        Me.radPickUp.Size = New System.Drawing.Size(72, 22)
        Me.radPickUp.TabIndex = 2
        Me.radPickUp.TabStop = True
        Me.radPickUp.Text = "Pick Up"
        Me.radPickUp.UseVisualStyleBackColor = True
        '
        'radTakeOut
        '
        Me.radTakeOut.AutoSize = True
        Me.radTakeOut.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radTakeOut.Location = New System.Drawing.Point(97, 22)
        Me.radTakeOut.Name = "radTakeOut"
        Me.radTakeOut.Size = New System.Drawing.Size(79, 22)
        Me.radTakeOut.TabIndex = 1
        Me.radTakeOut.TabStop = True
        Me.radTakeOut.Text = "Take out"
        Me.radTakeOut.UseVisualStyleBackColor = True
        '
        'radInside
        '
        Me.radInside.AutoSize = True
        Me.radInside.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radInside.Location = New System.Drawing.Point(7, 22)
        Me.radInside.Name = "radInside"
        Me.radInside.Size = New System.Drawing.Size(65, 22)
        Me.radInside.TabIndex = 0
        Me.radInside.TabStop = True
        Me.radInside.Text = "Inside"
        Me.radInside.UseVisualStyleBackColor = True
        '
        'btnSubmitOrder
        '
        Me.btnSubmitOrder.BackColor = System.Drawing.Color.Cornsilk
        Me.btnSubmitOrder.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmitOrder.Location = New System.Drawing.Point(15, 526)
        Me.btnSubmitOrder.Name = "btnSubmitOrder"
        Me.btnSubmitOrder.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmitOrder.TabIndex = 22
        Me.btnSubmitOrder.Text = "Submit"
        Me.btnSubmitOrder.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.Cornsilk
        Me.btnClear.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(109, 526)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 23
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Cornsilk
        Me.btnExit.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(206, 526)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 24
        Me.btnExit.Text = "Exit "
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'frmPTsGrille
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSeaGreen
        Me.ClientSize = New System.Drawing.Size(324, 561)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSubmitOrder)
        Me.Controls.Add(Me.grpDestination)
        Me.Controls.Add(Me.cmbDrink)
        Me.Controls.Add(Me.lblDrinks)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.grpMeat)
        Me.Controls.Add(Me.grpCheese)
        Me.Controls.Add(Me.grpVeggieToppings)
        Me.Controls.Add(Me.grpBottleToppings)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmPTsGrille"
        Me.Text = "P.T.'s Grille Menu"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.grpBottleToppings.ResumeLayout(False)
        Me.grpBottleToppings.PerformLayout()
        Me.grpVeggieToppings.ResumeLayout(False)
        Me.grpVeggieToppings.PerformLayout()
        Me.grpCheese.ResumeLayout(False)
        Me.grpCheese.PerformLayout()
        Me.grpMeat.ResumeLayout(False)
        Me.grpMeat.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpDestination.ResumeLayout(False)
        Me.grpDestination.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radGrilledCheese As RadioButton
    Friend WithEvents radBltSandwich As RadioButton
    Friend WithEvents radTurkeySandwich As RadioButton
    Friend WithEvents radPtDog As RadioButton
    Friend WithEvents radBlackBean As RadioButton
    Friend WithEvents radGardenBurger As RadioButton
    Friend WithEvents radRoastBeef As RadioButton
    Friend WithEvents radGrilledChicken As RadioButton
    Friend WithEvents radPtBurger As RadioButton
    Friend WithEvents radOldFashionedBurger As RadioButton
    Friend WithEvents grpBottleToppings As GroupBox
    Friend WithEvents chkMustard As CheckBox
    Friend WithEvents chkKetchup As CheckBox
    Friend WithEvents chkMayo As CheckBox
    Friend WithEvents grpVeggieToppings As GroupBox
    Friend WithEvents chkPickels As CheckBox
    Friend WithEvents chkOnion As CheckBox
    Friend WithEvents chkTomato As CheckBox
    Friend WithEvents chkLettuce As CheckBox
    Friend WithEvents grpCheese As GroupBox
    Friend WithEvents radJack As RadioButton
    Friend WithEvents radAmerican As RadioButton
    Friend WithEvents grpMeat As GroupBox
    Friend WithEvents chkChili As CheckBox
    Friend WithEvents chkBacon As CheckBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents lblDrinks As Label
    Friend WithEvents cmbDrink As ComboBox
    Friend WithEvents grpDestination As GroupBox
    Friend WithEvents radPickUp As RadioButton
    Friend WithEvents radTakeOut As RadioButton
    Friend WithEvents radInside As RadioButton
    Friend WithEvents btnSubmitOrder As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
